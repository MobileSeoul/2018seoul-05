package appcontest.seoulsi_we

/**
 * Created by nam on 2018. 9. 25..
 */

class Consts {
    companion object {
        var DEVICE_ID = "unKnown"

        val SHARED_PREFERENCE_KEY = "sharedPreference"
        val RECENT_SEARCH_SHARED_PREFERENCE_KEY = "recentSearchedKeyword"
    }
}