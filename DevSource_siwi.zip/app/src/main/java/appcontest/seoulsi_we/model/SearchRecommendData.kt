package appcontest.seoulsi_we.model

import com.google.gson.annotations.SerializedName

/**
 * Created by nam on 2018. 9. 30..
 */
class SearchRecommendData{
    @SerializedName("keyword") var keyword: String? = null
}